"""Cogem: provider-neutral coordination and graph analysis for multi-agent work."""

from .contracts import (
    AgentMessage,
    ContractError,
    DecisionRecord,
    HandoffRecord,
    ReportRecord,
    ReviewProof,
    TaskRecord,
)
from .scope import ScopeChange, ScopeCheckResult
from .state import CogemState, load_state

__all__ = [
    "AgentMessage",
    "CogemState",
    "ContractError",
    "DecisionRecord",
    "HandoffRecord",
    "ReportRecord",
    "ReviewProof",
    "ScopeChange",
    "ScopeCheckResult",
    "TaskRecord",
    "load_state",
]

__version__ = "4.0.0"
