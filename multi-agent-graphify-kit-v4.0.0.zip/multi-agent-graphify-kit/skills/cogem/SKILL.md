---
name: cogem
description: Use when multiple agents must change interconnected project files without losing shared decisions, ownership boundaries, dependency context, actual-change scope, dispatch authorization, or independent review evidence.
---

# Cogem

## Overview

Cogem coordinates graph-aware multi-agent work through explicit Task contracts and deterministic evidence. Parallelism, dispatch, Skill risk, actual write scope, and review must be proven rather than assumed.

## Required topology

Plan A uses Coordinator, Graph Analyst, Worker A, Worker B, and a fresh-context read-only Independent Reviewer. At most two source Writers operate concurrently, preferably in isolated worktrees. High-risk work runs the same reviewer role again in a separate adversarial session.

## Before dispatch

1. Create a Task with exact scopes, dependencies, acceptance commands, required `review_level`, and unique lease.
2. Any `write_set` at or below `skills/` must use `high-risk`.
3. Run graph and validation.
4. Run `dispatch-check TASK-NNN`; exit code `0` authorizes work and records the immutable scope baseline.

## During work

Workers modify only `write_set`, record structured messages, and stop on scope expansion. `Comm.md` is generated; only Operator Notes are manually editable.

For new Skills, use `skill-init` when practical. Skill roots allow `agents/`, `assets/`, `references/`, `scripts/`, `schemas/`, and `tests/`; every file remains manifest-controlled.

## Before handoff or review

```bash
python scripts/cogem.py skill-check --root .
python scripts/cogem.py scope-check TASK-NNN --root .
python scripts/cogem.py validate --root .
```

`scope-check` detects created, modified, and deleted paths, rejects writes outside scope, and requires `manifest.txt` to change with Skill content.

## Review

Record `review_tree_hash`, then run a fresh read-only independent Antigravity review. High-risk work also requires a separate adversarial pass against the same hash with no prior findings.

## References

- [Communication protocol](references/communication-protocol.md)
- [Agent runtime policy](references/agent-model.md)
- [Graph model](references/graph-model.md)
- [Parallel safety](references/parallel-safety.md)
- [Skill authoring gate](references/skill-authoring.md)
- [Command reference](references/commands.md)
