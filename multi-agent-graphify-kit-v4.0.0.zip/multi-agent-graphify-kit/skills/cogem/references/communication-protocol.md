# Cogem Communication Protocol

`.agents/` is the source of truth. `Comm.md` is a generated view after bootstrap.

## Record classes

- `tasks/`: scope, owner, status, lease, dependencies, acceptance commands, and review level;
- `messages/`: append-only progress, questions, answers, blockers, and review notifications;
- `decisions/`: shared choices and rationale;
- `handoffs/`: artifacts and evidence transferred to a dependent agent;
- `reports/`: deterministic verification and semantic review evidence;
- `snapshots/`: immutable dispatch baselines and persisted actual-change scope results.

IDs are unique within their record class. Agents create a new record instead of overwriting another agent's record.

## Bootstrap

A release contains no live records. The Coordinator may create the first coordination records without a task, but this exception cannot be used to change source files.

## Review reports

`independent-review` and `adversarial-review` reports include `review_proof`. The proof records the external engine, session ID, fresh-context status, read-only permissions, no-source-write status, reviewed tree hash, prior-findings isolation, prompt mode, and pass index.

The first pass uses `prompt_mode: independent` and `pass_index: 1`. The second high-risk pass uses `prompt_mode: adversarial`, `pass_index: 2`, and `prior_findings_provided: false`.

## Comm.md ownership

Only the Coordinator or `cogem sync` writes generated sections. Operators may edit only the marked Operator Notes block.
