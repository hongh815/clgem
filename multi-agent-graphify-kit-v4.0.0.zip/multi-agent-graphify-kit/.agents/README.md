# Cogem Coordination State

A portable release contains no live Task, message, decision, handoff, report, or scope snapshot JSON. `.gitkeep` files retain the directories and `templates/` provides complete examples.

- `tasks/`: Task contracts;
- `messages/`: append-only communication;
- `decisions/`: shared decisions;
- `handoffs/`: transfer records;
- `reports/`: command and review evidence;
- `snapshots/`: immutable dispatch baselines and persisted scope-check results;
- `templates/`: record examples.

The Coordinator may bootstrap coordination records and generated artifacts, but source work requires a real Task and lease. A successful `dispatch-check` creates the Task snapshot. `scope-check` must pass before handoff or review.
