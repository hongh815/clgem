# Agent Roles

## Coordinator

Owns the plan, bootstrap coordination records, task contracts, decisions, dependency order, leases, integration, `Comm.md`, dispatch authorization, and final task state transitions. Bootstrap authority is limited to `.agents/`, `.graph/`, and generated `Comm.md`; it cannot modify project source.

## Graph Analyst

Builds and interprets project graphs, impact relationships, and parallel-safety results. It writes generated artifacts only unless separately assigned a scoped task.

## Worker A and Worker B

Implement disjoint work packages under exact `write_set` boundaries. They receive fresh task contexts, stop on scope expansion, and provide acceptance evidence and handoffs.

## Independent Reviewer

Runs externally through the configured Antigravity engine in a fresh, read-only session. It reviews the integrated current tree and writes a report with machine-readable `review_proof`. It never repairs source under the review assignment.

High-risk work launches the same role again in a separate fresh adversarial session. The second pass is not a permanent sixth role and does not receive prior findings before forming its own conclusions.
