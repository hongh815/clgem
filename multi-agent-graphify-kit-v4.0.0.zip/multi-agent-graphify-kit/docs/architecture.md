# Cogem Architecture

Cogem separates external agent execution from deterministic project governance.

```text
External runtime
  ├─ Coordinator
  ├─ Graph Analyst
  ├─ Worker A / Worker B
  └─ Independent Reviewer
          │
          ▼
.agents/*.json ── cogem sync ─────────> Comm.md
project tree ──── cogem graph ────────> .graph/*
skills/* ──────── cogem skill-check ──> Skill diagnostics
task + graph ──── cogem dispatch-check> authorization + baseline
baseline + tree ─ cogem scope-check ──> actual-change evidence
all inputs ────── cogem validate ─────> repository diagnostics
```

## Main boundaries

- `.agents/` is structured coordination state.
- `.agents/snapshots/` stores immutable dispatch baselines and scope results.
- `.graph/` is generated analysis state.
- `skills/*/manifest.txt` is authoritative inside each Skill.
- the external runtime owns model sessions and filesystem permissions.

## Hash boundaries

The graph fingerprint excludes generated graph data, communication churn, reports, and scope snapshots. Recording dispatch evidence therefore does not immediately stale the graph.

The scope baseline hashes reviewable project files while excluding generated artifacts, secrets, `Comm.md`, and live coordination records. The scope result records the current reviewable-tree hash.

The review hash excludes all `.agents/` state, so evidence records do not alter their own target.

## Concurrency boundary

Path-intersection analysis decides whether Task contracts are theoretically parallel-safe. Actual-change snapshots operate per filesystem tree. Parallel Writers therefore require isolated worktrees or equivalent task-isolated checkouts for attributable scope evidence.

## Determinism

Graph ordering, diagnostics, hashes, manifests, JSON output, and archive ordering are stable for identical inputs. The packager uses a fixed archive timestamp.
