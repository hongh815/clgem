# Cogem Execution Workflow

## Phase 0: Bootstrap

The Coordinator may create coordination records and generated artifacts, but not source changes. Every real Task explicitly declares `review_level`.

## Phase 1: Define

Declare owner, exact read/write/impact scopes, dependencies, acceptance commands, unique lease, and risk level. A Task touching `skills/` must be `high-risk`; this is automatically enforced.

## Phase 2: Analyze

```bash
python scripts/cogem.py skill-check --root .
python scripts/cogem.py graph --root .
python scripts/cogem.py validate --root .
```

Inspect the graph, broken references, dependency closure, and core impact.

## Phase 3: Schedule and dispatch

```bash
python scripts/cogem.py parallel TASK-001 TASK-002 --root .
python scripts/cogem.py dispatch-check TASK-001 --root .
```

A successful dispatch writes `.agents/snapshots/TASK-001.json`. The baseline cannot be silently replaced by changing scope or lease. Parallel Workers should operate in isolated worktrees.

## Phase 4: Execute

Workers modify only `write_set`, record progress, and stop on scope expansion. New Skills may be scaffolded with `skill-init`; all Skill files remain manifest-controlled.

## Phase 5: Scope verification and handoff

Before any handoff or review transition:

```bash
python scripts/cogem.py scope-check TASK-001 --root .
```

The command compares the current tree to the dispatch baseline, detects created/modified/deleted paths, verifies `write_set`, enforces Skill risk, and requires a same-Task manifest update for Skill content changes. Cogem persists the result. `validate` rejects handoff or review states without passing evidence.

## Phase 6: Integrate and review

Integrate in dependency order, refresh graph and `Comm.md`, record `review_tree_hash`, then launch a fresh read-only Antigravity independent review. Repairs become new Tasks.

## Phase 7: High-risk adversarial pass

High-risk work launches a second fresh Antigravity session using prompt mode `adversarial`, pass index `2`, and no prior findings. Both reviews target the same Task-bound hash.

## Phase 8: Release

Run tests, compile checks, Skill policy, graph generation, and validation. Remove live Task, snapshot, handoff, message, decision, report, and graph artifacts before creating the portable ZIP; then verify the ZIP in a fresh extraction.
