print("sample")
