# Cogem Agent Operating Instructions

These instructions apply to every agent working in this repository.

## Bootstrap authority

A fresh distribution has no live Task, scope snapshot, or `.graph/` output. The Coordinator may create coordination records, generate `.graph/`, regenerate `Comm.md`, and run read-only planning or validation without a Task. Bootstrap authority never permits source, documentation, configuration, schema, script, or Skill changes.

## Mandatory preflight

Before a Worker modifies a file:

1. Read `Comm.md`, the assigned Task, accepted decisions, and relevant graph artifacts.
2. Confirm owner, lease, `read_set`, `write_set`, impacts, dependencies, acceptance commands, and explicit `review_level`.
3. Run `python scripts/cogem.py graph --root .` after contract or structural changes.
4. Run `python scripts/cogem.py validate --root .`.
5. Run `python scripts/cogem.py dispatch-check TASK-NNN --root .` immediately before execution.

Exit code `0` authorizes work and creates an immutable dispatch baseline in `.agents/snapshots/`. A path absent from `write_set` is read-only.

## Skill changes

Every path at or below `skills/` is a critical path. Cogem blocks dispatch and validation unless the Task declares `review_level: high-risk`.

- Follow [Skill Authoring Policy](docs/skill-authoring.md).
- Use `cogem skill-init NAME` for new Skills when practical.
- Keep `manifest.txt` synchronized in the same Task.
- Run `cogem skill-check` and `cogem scope-check TASK-NNN` before handoff.
- Require both independent and adversarial Antigravity review passes.

## Role rules

### Coordinator

- Own decomposition, dependencies, leases, decisions, integration, and generated `Comm.md`.
- Permit at most two simultaneous source writers, preferably in isolated worktrees.
- Run `parallel` for each concurrent pair and `dispatch-check` immediately before each Worker starts.
- Reject a handoff or review request without passing scope evidence.
- Convert scope expansion into a revised or new Task; never rebase a baseline after work begins.

### Graph Analyst

- Write only generated graph artifacts unless separately assigned scoped source work.
- Rebuild after structural or Task-contract changes.
- Report broken references, stale inputs, and high-impact nodes without repairing source.

### Worker A and Worker B

- Modify only the assigned `write_set`.
- Stop and report a blocker when work exceeds scope.
- Record structured progress and run every acceptance command.
- Run `scope-check TASK-NNN` before creating a handoff or requesting review.

### Independent Reviewer

- Use the configured Antigravity engine in a fresh, read-only session.
- Review integrated artifacts and command evidence rather than Worker conversation history.
- Bind findings to `review_tree_hash` and complete `review_proof`.
- Do not repair source; repairs become new scoped Tasks.
- For high-risk work, run a second isolated adversarial session without prior findings.

## Skill file contract

A Skill root permits only:

```text
SKILL.md  manifest.txt  agents/  assets/  references/  scripts/  schemas/  tests/
```

Names are 1–63 lowercase alphanumeric, hyphen-separated characters. Frontmatter contains exactly `name` and `description` as single-line scalars, and the description starts with `Use when`.

## Completion contract

Before handoff or `review_ready`:

```bash
python scripts/cogem.py scope-check TASK-NNN --root .
```

Then confirm acceptance commands, JSON parsing, Markdown links, Skill policy, and graph freshness. `cogem validate` must find the passing persisted scope result.

Before review, the Coordinator records `cogem review-hash` in `review_tree_hash`. Standard work requires one matching independent review. High-risk work requires a second matching adversarial review.

Final deterministic gate:

```bash
python scripts/run_tests.py
python -m compileall -q src scripts skills/cogem/scripts
python scripts/cogem.py skill-check --root .
python scripts/cogem.py all --root .
```
